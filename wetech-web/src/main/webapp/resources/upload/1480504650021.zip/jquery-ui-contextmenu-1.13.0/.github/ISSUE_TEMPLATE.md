Thanks for contributing :-)

Please add info below, then remove all unneeded lines from this issue report.


### Expected and actual behavior

... (Maybe even a screenshot? Any hints on the browser's debug console?)


### Steps to reproduce the problem

  1. ...
  2. ...

Could you set up a jsFiddle (http://jsfiddle.net/mar10/6o3u8a88/) or
Plunker (http://plnkr.co/edit/Bbcoqy?p=preview) ?


### Environment

  - Browser type and version:
  - jQuery and jQuery UI versions:
  - ui-contextmenu version:    
