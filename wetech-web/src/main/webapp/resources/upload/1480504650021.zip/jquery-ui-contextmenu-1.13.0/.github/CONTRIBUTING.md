Thanks for contributing :+1:

In lieu of an own guideline, please have a look at the 
[Fancytree Contributing Guidelines](https://github.com/mar10/fancytree/wiki/HowtoContribute#report-issues).
